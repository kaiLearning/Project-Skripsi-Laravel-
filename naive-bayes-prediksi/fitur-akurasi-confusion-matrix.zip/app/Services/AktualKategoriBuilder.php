<?php
namespace App\Services;

use Illuminate\Support\Facades\DB;

class AktualKategoriBuilder
{
    /**
     * Hitung & isi aktual_kategori di prediksis dari penjualans + rules.
     * GANTI nama kolom di komentar jika berbeda.
     */
    public function build(?string $start = null, ?string $end = null): int
    {
        // Jika rules pakai kolom 'kategori_produk' (string). Jika pakai ID, ubah groupBy & lookup sesuai komentar.
        $rules = DB::table('rules')->get()->groupBy('kategori_produk');

        // Agregasi transaksi per produk per hari
        $q = DB::table('penjualans as p')
            ->selectRaw('p.produk_id, DATE(p.created_at) as tgl')   // GANTI jika pakai kolom tanggal lain (mis: p.tanggal)
            ->selectRaw('SUM(p.jumlah) as sum_jumlah')              // GANTI jika kuantitas bernama lain (mis: qty)
            ->selectRaw('SUM(p.total_harga) as sum_total_harga')
            ->groupBy('p.produk_id','tgl');

        if ($start) $q->whereDate('p.created_at','>=',$start);
        if ($end)   $q->whereDate('p.created_at','<=',$end);

        $rows = $q->get();

        $upserts = [];
        foreach ($rows as $r) {
            // Ambil kategori produk. Jika master_produks pakai kategori_id, ubah ke lookup ID sesuai kebutuhan.
            $kategoriProduk = DB::table('master_produks')->where('id',$r->produk_id)->value('kategori_produk');

            $rule = optional($rules->get($kategoriProduk))->first();

            $isTinggi = false;
            if ($rule) {
                $minJ = $rule->min_jumlah ?? PHP_INT_MAX;
                $minH = $rule->min_harga  ?? PHP_INT_MAX;
                $isTinggi = ($r->sum_jumlah >= $minJ) || ($r->sum_total_harga >= $minH);
            } else {
                $isTinggi = $r->sum_jumlah > 0;
            }
            $aktual = $isTinggi ? 'Tinggi' : 'Rendah';

            $predAda = DB::table('prediksis')
                ->where('produk_id',$r->produk_id)
                ->whereDate('tanggal',$r->tgl)
                ->exists();

            if ($predAda) {
                $upserts[] = [
                    'produk_id'       => $r->produk_id,
                    'tanggal'         => $r->tgl,
                    'aktual_kategori' => $aktual,
                    'updated_at'      => now(),
                ];
            }
        }

        if ($upserts) {
            DB::table('prediksis')->upsert(
                $upserts,
                ['produk_id','tanggal'],
                ['aktual_kategori','updated_at']
            );
        }
        return count($upserts);
    }
}
