<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Services\ConfusionMatrix;

class AkurasiController extends Controller
{
    public function index(Request $req, ConfusionMatrix $cm)
    {
        $q = DB::table('prediksis')->select('aktual_kategori','prediksi_kategori');

        if ($req->filled('start'))  $q->whereDate('tanggal','>=',$req->get('start'));
        if ($req->filled('end'))    $q->whereDate('tanggal','<=',$req->get('end'));
        if ($req->filled('produk')) $q->where('produk_id',$req->get('produk'));

        $pairs = $q->whereNotNull('aktual_kategori')->get();

        $actual    = $pairs->pluck('aktual_kategori')->toArray();
        $predicted = $pairs->pluck('prediksi_kategori')->toArray();

        $labelsParam = $req->get('labels');
        $labels = $labelsParam ? array_map('trim', explode(',', $labelsParam)) : ['Rendah','Tinggi'];

        $r = $cm->compute($actual,$predicted,$labels);

        return view('akurasi.index', [
            'labels'   => $r['labels'],
            'matrix'   => $r['matrix'],
            'support'  => $r['support'],
            'perClass' => $r['per_class'],
            'accuracy' => $r['accuracy'],
            'macro'    => $r['macro_avg'],
            'micro'    => $r['micro_avg'],
            'total'    => array_sum(array_map('array_sum', $r['matrix'])),
        ]);
    }
}
