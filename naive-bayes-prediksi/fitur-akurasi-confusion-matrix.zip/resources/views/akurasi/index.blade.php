@extends('layouts.app')

@section('content')
<div class="container">
  <h3 class="mb-3">Evaluasi Akurasi (Confusion Matrix)</h3>

  <form class="row g-2 mb-3" method="get">
    <div class="col-auto">
      <input type="date" name="start" class="form-control" value="{{ request('start') }}" placeholder="Start">
    </div>
    <div class="col-auto">
      <input type="date" name="end" class="form-control" value="{{ request('end') }}" placeholder="End">
    </div>
    <div class="col-auto">
      <input type="text" name="produk" class="form-control" value="{{ request('produk') }}" placeholder="Produk ID">
    </div>
    <div class="col-auto">
      <input type="text" name="labels" class="form-control" value="{{ request('labels') }}" placeholder="Urutan label (cth: Rendah,Tinggi)">
    </div>
    <div class="col-auto">
      <button class="btn btn-primary">Terapkan</button>
    </div>
  </form>

  <div class="card mb-4">
    <div class="card-body">
      <h5 class="card-title mb-3">Ringkasan</h5>
      <p class="mb-1">Total sampel: <strong>{{ $total }}</strong></p>
      <p class="mb-1">Accuracy: <strong>{{ number_format($accuracy*100, 2) }}%</strong></p>
      <p class="mb-1">Macro Avg — Precision: <strong>{{ number_format($macro['precision']*100,2) }}%</strong>,
        Recall: <strong>{{ number_format($macro['recall']*100,2) }}%</strong>,
        F1: <strong>{{ number_format($macro['f1']*100,2) }}%</strong></p>
      <p class="mb-0">Micro Avg — Precision: <strong>{{ number_format($micro['precision']*100,2) }}%</strong>,
        Recall: <strong>{{ number_format($micro['recall']*100,2) }}%</strong>,
        F1: <strong>{{ number_format($micro['f1']*100,2) }}%</strong></p>
    </div>
  </div>

  <div class="card mb-4">
    <div class="card-body table-responsive">
      <h5 class="card-title mb-3">Confusion Matrix</h5>
      <table class="table table-bordered align-middle text-center">
        <thead>
          <tr>
            <th>Aktual \ Prediksi</th>
            @foreach($labels as $pred) <th>{{ $pred }}</th> @endforeach
            <th class="bg-light">Support</th>
          </tr>
        </thead>
        <tbody>
          @foreach($matrix as $i => $row)
            <tr>
              <th class="text-start">{{ $labels[$i] }}</th>
              @foreach($row as $j => $val)
                <td class="{{ $i === $j ? 'table-success' : '' }}">{{ $val }}</td>
              @endforeach
              <td class="bg-light">{{ $support[$labels[$i]] }}</td>
            </tr>
          @endforeach
        </tbody>
      </table>
    </div>
  </div>

  <div class="card">
    <div class="card-body table-responsive">
      <h5 class="card-title mb-3">Metrik Per Kelas</h5>
      <table class="table table-striped text-center">
        <thead>
          <tr>
            <th>Kelas</th><th>TP</th><th>FP</th><th>FN</th><th>TN</th>
            <th>Precision</th><th>Recall</th><th>F1</th>
          </tr>
        </thead>
        <tbody>
          @foreach($perClass as $label => $m)
            <tr>
              <td class="text-start">{{ $label }}</td>
              <td>{{ $m['tp'] }}</td>
              <td>{{ $m['fp'] }}</td>
              <td>{{ $m['fn'] }}</td>
              <td>{{ $m['tn'] }}</td>
              <td>{{ number_format($m['precision']*100,2) }}%</td>
              <td>{{ number_format($m['recall']*100,2) }}%</td>
              <td>{{ number_format($m['f1']*100,2) }}%</td>
            </tr>
          @endforeach
        </tbody>
      </table>
    </div>
  </div>

</div>
@endsection
